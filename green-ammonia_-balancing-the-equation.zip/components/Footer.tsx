
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-green-dark text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Green Ammonia Initiative</h3>
            <p className="text-brand-green-light max-w-md">
              Advocating for a sustainable shift in industrial chemistry to protect our planet for future generations.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">References</h3>
            <ul className="space-y-2 text-sm text-brand-green-light">
              <li>
                International Renewable Energy Agency (IRENA). (2021). Green Hydrogen: A Guide to Policy Making.
              </li>
              <li>
                The Royal Society. (2024). Ammonia: zero-carbon fertilizer, fuel and energy store.
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-brand-green pt-8 text-center text-sm text-brand-green-light">
          <p className="mb-2">A project by Group 2 of 11 - St. Agatha, Holy Angel University.</p>
          <p>&copy; {new Date().getFullYear()} Green Ammonia Initiative. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;