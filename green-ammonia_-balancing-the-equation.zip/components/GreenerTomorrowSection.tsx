
import React, { ReactNode } from 'react';
import Section from './Section';
import AnimateOnScroll from './AnimateOnScroll';
// FIX: Import LeafIcon to resolve 'Cannot find name' error.
import { WindIcon, WaveIcon, WheatIcon, ShipIcon, PowerIcon, PlanetIcon, LeafIcon } from './Icons';

interface BenefitCircleProps {
    icon: ReactNode;
    title: string;
    style?: React.CSSProperties;
    className?: string;
    angle: number;
}

const BenefitCircle: React.FC<BenefitCircleProps> = ({ icon, title, style, className, angle }) => {
    // Positioning logic for a circle layout
    const radius = 'min(40vw, 28rem)'; // Responsive radius
    const top = `calc(50% - ${radius} * ${Math.sin(angle * Math.PI / 180)})`;
    const left = `calc(50% + ${radius} * ${Math.cos(angle * Math.PI / 180)})`;

    return (
        <div 
            className={`absolute transform -translate-x-1/2 -translate-y-1/2 text-center transition-opacity duration-1000 ${className}`}
            style={{ ...style, top, left }}
        >
            <div className="w-24 h-24 md:w-32 md:h-32 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center animate-float">
                <div className="w-20 h-20 md:w-24 md:h-24 bg-brand-green-dark rounded-full flex items-center justify-center shadow-lg">
                    {icon}
                </div>
            </div>
            <p className="mt-2 text-sm md:text-base font-bold text-white" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}>{title}</p>
        </div>
    );
};

const GreenerTomorrowSection: React.FC = () => {
    const benefits = [
        { icon: <WindIcon className="h-10 w-10 md:h-12 md:w-12 text-white" />, title: "Cleaner Air" },
        { icon: <WaveIcon className="h-10 w-10 md:h-12 md:w-12 text-white" />, title: "Thriving Oceans" },
        { icon: <WheatIcon className="h-10 w-10 md:h-12 md:w-12 text-white" />, title: "Sustainable Farming" },
        { icon: <ShipIcon className="h-10 w-10 md:h-12 md:w-12 text-white" />, title: "Carbon-Free Shipping" },
        { icon: <PowerIcon className="h-10 w-10 md:h-12 md:w-12 text-white" />, title: "Renewable Energy Grid" },
        { icon: <PlanetIcon className="h-10 w-10 md:h-12 md:w-12 text-white" />, title: "A Healthier Planet" },
    ];

    return (
        <Section
            id="tomorrow"
            title="A Greener Tomorrow"
            subtitle="The positive ripple effect of a single, powerful change."
            className="bg-gray-800 text-white !py-24 md:!py-32"
        >
            <AnimateOnScroll className="fade-in-up">
              <div className="relative w-full h-[600px] md:h-[700px] hidden md:block">
                  <svg className="absolute inset-0 w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
                      {benefits.map((_, index) => {
                          const angle = index * 60;
                          const radius = 28 * 16; // 28rem in pixels
                          const endX = 50 + (radius / 700 * 100) * Math.cos(angle * Math.PI / 180);
                          const endY = 50 - (radius / 700 * 100) * Math.sin(angle * Math.PI / 180);
                          return (
                            <line
                                key={index}
                                x1="50%" y1="50%"
                                x2={`${endX}%`} y2={`${endY}%`}
                                className="tomorrow-line stroke-green-300/30"
                                strokeWidth="2"
                                style={{ transitionDelay: `${index * 200 + 500}ms` }}
                            />
                          )
                      })}
                  </svg>
                  
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                      <div className="w-48 h-48 bg-brand-green rounded-full flex flex-col items-center justify-center animate-pulse-glow shadow-2xl">
                          <LeafIcon className="h-16 w-16 text-white" />
                          <p className="text-white font-bold text-lg mt-2">Green Ammonia</p>
                      </div>
                  </div>

                  {benefits.map((benefit, index) => (
                      <BenefitCircle
                          key={index}
                          icon={benefit.icon}
                          title={benefit.title}
                          angle={index * 60}
                          className="opacity-0"
                          style={{ transitionDelay: `${index * 200 + 800}ms`, animationDelay: `${index * 300}ms` }}
                      />
                  ))}
              </div>

               {/* Mobile Layout */}
              <div className="block md:hidden space-y-8">
                {benefits.map((benefit, index) => (
                   <AnimateOnScroll key={index} className="pop-in" style={{ transitionDelay: `${index * 100}ms` }}>
                     <div className="flex items-center gap-4 bg-white/10 p-4 rounded-lg">
                        <div className="w-16 h-16 bg-brand-green-dark rounded-full flex items-center justify-center flex-shrink-0">
                           {benefit.icon}
                        </div>
                        <h3 className="text-lg font-bold text-white">{benefit.title}</h3>
                     </div>
                   </AnimateOnScroll>
                ))}
              </div>


              <AnimateOnScroll className="fade-in-up" style={{ transitionDelay: '1800ms' }}>
                <div className="text-center mt-16 md:mt-24">
                  <h3 className="text-2xl md:text-3xl font-bold text-white">
                    One Change. A World of Difference.
                  </h3>
                   <p className="text-xl text-brand-green-light mt-2">Be Part of the Solution.</p>
                </div>
              </AnimateOnScroll>
            </AnimateOnScroll>
        </Section>
    );
};

export default GreenerTomorrowSection;
