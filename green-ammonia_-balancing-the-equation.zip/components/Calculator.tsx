import React, { useState, useMemo } from 'react';
import Section from './Section';
import AnimateOnScroll from './AnimateOnScroll';

const CO2_PER_TONNE_AMMONIA = 1.87;

const Calculator: React.FC = () => {
    const [tonnes, setTonnes] = useState<number>(1000);

    const co2Saved = useMemo(() => {
        return (tonnes * CO2_PER_TONNE_AMMONIA).toLocaleString(undefined, {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        });
    }, [tonnes]);
    
    const equivalentCars = useMemo(() => {
        const co2MetricTons = tonnes * CO2_PER_TONNE_AMMONIA;
        // Avg passenger vehicle emits ~4.6 metric tons of CO2 per year (EPA)
        return (co2MetricTons / 4.6).toLocaleString(undefined, {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        });
    }, [tonnes]);

    return (
        <Section
            id="calculator"
            title="Calculate the Impact"
            subtitle="See the real-world difference switching to Green Ammonia can make."
            className="bg-brand-green-light"
        >
            <AnimateOnScroll className="fade-in-up">
              <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-2xl">
                  <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div>
                          <label htmlFor="ammonia-tonnes" className="block text-lg font-semibold text-gray-700 mb-2">
                              Amount of Ammonia (in tonnes)
                          </label>
                          <input
                              type="range"
                              id="ammonia-tonnes"
                              min="100"
                              max="1000000"
                              step="100"
                              value={tonnes}
                              onChange={(e) => setTonnes(Number(e.target.value))}
                              className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                          />
                           <div className="text-center mt-2 text-2xl font-bold text-brand-green-dark">
                             {tonnes.toLocaleString()} tonnes
                          </div>
                      </div>
                      <div className="text-center p-6 bg-brand-bg rounded-lg">
                          <p className="text-lg text-gray-600">By switching this amount to Green Ammonia, you would save:</p>
                          <p className="text-4xl font-bold text-brand-green-dark my-2">{co2Saved}</p>
                          <p className="text-lg text-gray-800">tonnes of CO₂</p>
                          <p className="text-md text-gray-500 mt-4">That's equivalent to taking</p>
                          <p className="text-2xl font-bold text-brand-brown">{equivalentCars}</p>
                          <p className="text-md text-gray-500">cars off the road for a year!</p>
                      </div>
                  </div>
                   <p className="text-xs text-center text-gray-400 mt-6">*Calculation based on an emission factor of {CO2_PER_TONNE_AMMONIA} tonnes of CO₂ per tonne of conventional ammonia.</p>
              </div>
            </AnimateOnScroll>
        </Section>
    );
};

export default Calculator;