
import React, { useState, useEffect, useRef } from 'react';

const CO2Counter: React.FC = () => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLDivElement>(null);
    const [isVisible, setIsVisible] = useState(false);
    const endValue = 662; // Represents 662 million tonnes
    const duration = 2500; // in milliseconds

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { threshold: 0.5 }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => observer.disconnect();
    }, []);

    useEffect(() => {
        if (!isVisible) return;

        let startTime: number | null = null;

        const animate = (timestamp: number) => {
            if (!startTime) startTime = timestamp;
            const progress = timestamp - startTime;
            const percentage = Math.min(progress / duration, 1);
            
            setCount(Math.floor(percentage * endValue));

            if (progress < duration) {
                requestAnimationFrame(animate);
            }
        };

        requestAnimationFrame(animate);

    }, [isVisible]);

    return (
        <div ref={ref} className="text-center p-6 bg-red-50 rounded-lg border-2 border-red-200">
            <h3 className="text-xl font-semibold text-gray-700 mb-4">A Staggering Impact</h3>
            <p className="text-6xl md:text-7xl font-bold text-red-500 my-2">
                {count.toLocaleString()}
            </p>
            <p className="text-2xl text-gray-800 font-semibold">Million Tonnes of CO₂</p>
        </div>
    );
};

export default CO2Counter;