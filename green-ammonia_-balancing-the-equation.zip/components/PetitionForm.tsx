import React, { useState, FormEvent } from 'react';
import Section from './Section';
import AnimateOnScroll from './AnimateOnScroll';

const PetitionForm: React.FC = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [submitted, setSubmitted] = useState(false);
    const [signerCount, setSignerCount] = useState(7);

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (name && email) {
            setSubmitted(true);
            setSignerCount(count => count + 1);
            setName('');
            setEmail('');
            setTimeout(() => setSubmitted(false), 5000);
        }
    };

    return (
        <Section
            id="petition"
            title="Join the Movement"
            subtitle="Pledge your support for a future powered by Green Ammonia. Demand cleaner industrial practices from governments and corporations."
            className="bg-white"
        >
            <AnimateOnScroll className="fade-in-up">
              <div className="max-w-2xl mx-auto bg-gray-50 p-8 rounded-xl shadow-lg">
                  <div className="text-center mb-6">
                      <p className="text-lg text-gray-600">Join <span className="font-bold text-brand-green-dark">{signerCount.toLocaleString()}</span> others who have signed.</p>
                  </div>
                  {submitted ? (
                      <div className="text-center p-4 bg-brand-green-light text-brand-green-dark rounded-lg">
                          <h3 className="text-xl font-bold">Thank You!</h3>
                          <p>Your support makes a difference in building a greener future.</p>
                      </div>
                  ) : (
                      <form onSubmit={handleSubmit} className="space-y-4">
                          <div>
                              <label htmlFor="name" className="sr-only">Full Name</label>
                              <input
                                  type="text"
                                  id="name"
                                  placeholder="Your Full Name"
                                  value={name}
                                  onChange={(e) => setName(e.target.value)}
                                  required
                                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green"
                              />
                          </div>
                          <div>
                              <label htmlFor="email" className="sr-only">Email Address</label>
                              <input
                                  type="email"
                                  id="email"
                                  placeholder="Your Email Address"
                                  value={email}
                                  onChange={(e) => setEmail(e.target.value)}
                                  required
                                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green"
                              />
                          </div>
                          <button
                              type="submit"
                              className="w-full bg-brand-green text-white font-bold py-3 px-8 rounded-lg hover:bg-brand-green-dark transition-all duration-300 transform hover:scale-105 shadow-lg"
                          >
                              Sign the Petition
                          </button>
                      </form>
                  )}
              </div>
            </AnimateOnScroll>
        </Section>
    );
};

export default PetitionForm;