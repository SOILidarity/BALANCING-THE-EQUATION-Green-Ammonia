
import React from 'react';
import Section from './Section';
import AnimateOnScroll from './AnimateOnScroll';

const teamMembers = [
    { name: 'Canlas, Rinoa Heart J.', image: 'https://picsum.photos/seed/rinoa/200' },
    { name: 'Fausto, Pauline Gabrielle C.', image: 'https://picsum.photos/seed/pauline/200' },
    { name: 'Fausto, Romer Gerard G.', image: 'https://picsum.photos/seed/romer/200' },
    { name: 'Flores, Chase Jarish C.', image: 'https://picsum.photos/seed/chase/200' },
    { name: 'Manalili, Kio Akim B.', image: 'https://picsum.photos/seed/kio/200' },
    { name: 'Marquez, Miguel Carlo I.', image: 'https://picsum.photos/seed/miguel/200' },
];

const TeamSection: React.FC = () => {
    return (
        <Section
            id="team"
            title="Meet the Researchers"
            subtitle="The dedicated team behind this initiative, driving the change towards a sustainable future."
            className="bg-brand-bg"
        >
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
                {teamMembers.map((member, index) => (
                    <AnimateOnScroll
                        key={member.name}
                        className="pop-in"
                        style={{ transitionDelay: `${index * 100}ms` }}
                    >
                        <div className="text-center group">
                            <img
                                src={member.image}
                                alt={`Profile of ${member.name}`}
                                className="w-32 h-32 rounded-full mx-auto object-cover border-4 border-white shadow-lg group-hover:scale-105 transition-transform duration-300"
                            />
                            <h3 className="mt-4 font-bold text-brand-green-dark">{member.name}</h3>
                            <p className="text-sm text-gray-500">Researcher</p>
                        </div>
                    </AnimateOnScroll>
                ))}
            </div>
        </Section>
    );
};

export default TeamSection;
