import React from 'react';
import Section from './Section';
import { SunIcon, WaterIcon, ZapIcon, FactoryIcon } from './Icons';
import AnimateOnScroll from './AnimateOnScroll';

const SolutionSection: React.FC = () => {
  const steps = [
    { icon: <SunIcon className="h-12 w-12 mx-auto text-brand-yellow" />, title: "Renewable Energy", description: "Solar, wind, or hydro power provides clean electricity." },
    { icon: <WaterIcon className="h-12 w-12 mx-auto text-blue-500" />, title: "Water Electrolysis", description: "Clean electricity splits water (H₂O) into hydrogen (H₂) and oxygen (O₂)." },
    { icon: <ZapIcon className="h-12 w-12 mx-auto text-yellow-400" />, title: "Nitrogen Separation", description: "Nitrogen (N₂) is separated from the air we breathe." },
    { icon: <FactoryIcon className="h-12 w-12 mx-auto text-gray-600" />, title: "Green Synthesis", description: "Hydrogen and Nitrogen are combined via the Haber-Bosch process, powered by renewables, to create Green Ammonia (NH₃)." }
  ];

  return (
    <Section
      id="solution"
      title="The Viable Solution: Green Ammonia"
      subtitle="By reimagining the production process, we can create ammonia without the harmful carbon byproducts."
      className="relative overflow-hidden bg-animate-flow"
    >
      <div className="grid md:grid-cols-4 gap-8 text-center">
        {steps.map((step, index) => (
          <AnimateOnScroll 
            key={index} 
            className="pop-in"
            style={{ transitionDelay: `${index * 150}ms` }}
          >
            <div className="p-6 bg-white rounded-lg shadow-lg h-full">
              {step.icon}
              <h3 className="text-xl font-bold mt-4 mb-2 text-brand-green-dark">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          </AnimateOnScroll>
        ))}
      </div>
      <AnimateOnScroll className="fade-in-up" style={{ transitionDelay: '600ms' }}>
        <div className="mt-12 text-center">
            <p className="text-2xl font-bold text-brand-green-dark p-4 bg-white/70 rounded-lg inline-block shadow-md">
              The Result: Zero Carbon Byproducts. Purely Sustainable.
            </p>
        </div>
      </AnimateOnScroll>
    </Section>
  );
};

export default SolutionSection;