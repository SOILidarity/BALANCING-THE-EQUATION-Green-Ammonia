import React, { ReactNode } from 'react';
import AnimateOnScroll from './AnimateOnScroll';

interface SectionProps {
  id: string;
  children: ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
}

const Section: React.FC<SectionProps> = ({ id, children, className = '', title, subtitle }) => {
  return (
    <section id={id} className={`py-16 md:py-24 ${className}`}>
      <div className="container mx-auto px-6">
        {title && (
          <AnimateOnScroll className="fade-in-up">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-brand-green-dark mb-2">{title}</h2>
              {subtitle && <p className="text-lg text-gray-600 max-w-3xl mx-auto">{subtitle}</p>}
            </div>
          </AnimateOnScroll>
        )}
        {children}
      </div>
    </section>
  );
};

export default Section;