import React from 'react';
import Section from './Section';
import { GlobeIcon, SproutIcon, TractorIcon, ShipIcon } from './Icons';
import AnimateOnScroll from './AnimateOnScroll';

const BenefitsSection: React.FC = () => {
    const benefits = [
        {
            icon: <GlobeIcon className="h-10 w-10 text-brand-green" />,
            title: "Reduced GHG Emissions",
            description: "Eliminates CO₂ from the production process, directly combating climate change."
        },
        {
            icon: <SproutIcon className="h-10 w-10 text-brand-green" />,
            title: "Sustainable Agriculture",
            description: "Enables the creation of 'green fertilizers' that support food production without the carbon footprint."
        },
        {
            icon: <TractorIcon className="h-10 w-10 text-brand-green" />,
            title: "Supports Sustainable Practices",
            description: "Promotes the adoption of renewable energy and circular economy principles in the chemical industry."
        },
        {
            icon: <ShipIcon className="h-10 w-10 text-brand-green" />,
            title: "Clean Energy Carrier",
            description: "Acts as a stable, dense carrier for hydrogen, making it a promising clean fuel for shipping and power generation."
        }
    ];

    return (
        <Section
            id="benefits"
            title="Environmental & Economic Benefits"
            subtitle="Adopting Green Ammonia unlocks a cascade of positive changes for our planet and industries."
            className="bg-white"
        >
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                {benefits.map((benefit, index) => (
                    <AnimateOnScroll
                        key={index}
                        className="pop-in"
                        style={{ transitionDelay: `${index * 100}ms` }}
                    >
                        <div 
                            className="bg-gray-50 p-6 rounded-xl shadow-md hover:shadow-xl hover:-translate-y-2 transition-all duration-300 h-full"
                        >
                            <div className="flex items-center gap-4 mb-4">
                                {benefit.icon}
                                <h3 className="text-xl font-bold text-brand-green-dark">{benefit.title}</h3>
                            </div>
                            <p className="text-gray-600">{benefit.description}</p>
                        </div>
                    </AnimateOnScroll>
                ))}
            </div>
        </Section>
    );
};

export default BenefitsSection;