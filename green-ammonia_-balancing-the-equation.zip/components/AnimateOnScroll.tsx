import React, { useRef, useEffect, ReactNode } from 'react';

interface AnimateOnScrollProps {
    children: ReactNode;
    className?: string;
    style?: React.CSSProperties;
}

const AnimateOnScroll: React.FC<AnimateOnScrollProps> = ({ children, className = '', style }) => {
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const element = ref.current;
        if (!element) return;

        // Ensure we don't re-observe an element that's already visible
        if (element.classList.contains('is-visible')) return;

        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    element.classList.add('is-visible');
                    observer.unobserve(element);
                }
            },
            { threshold: 0.1 }
        );

        observer.observe(element);

        return () => observer.disconnect();
    }, []);

    return (
        <div ref={ref} className={`animate-on-scroll ${className}`} style={style}>
            {children}
        </div>
    );
};

export default AnimateOnScroll;
