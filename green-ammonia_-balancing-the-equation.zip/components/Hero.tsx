
import React, { useState, useEffect } from 'react';

const Hero: React.FC = () => {
  const [offsetY, setOffsetY] = useState(0);
  const handleScroll = () => setOffsetY(window.pageYOffset);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section id="home" className="relative h-screen flex items-center justify-center text-white overflow-hidden">
      <div className="absolute inset-0 bg-animate-aurora opacity-60 z-10"></div>
      <img 
        src="https://picsum.photos/1920/1080?grayscale&blur=2" 
        alt="Green industrial landscape" 
        className="absolute inset-0 w-full h-full object-cover"
        style={{ transform: `translateY(${offsetY * 0.4}px)` }}
      />
      <div className="relative z-20 text-center p-6">
        <h1 className="text-4xl md:text-6xl font-bold mb-4" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.7)' }}>
          Balancing the Equation
        </h1>
        <p className="text-xl md:text-2xl mb-8" style={{ textShadow: '1px 1px 3px rgba(0,0,0,0.7)' }}>
          Green Ammonia for a Greener Earth
        </p>
        <a href="#problem" className="bg-brand-green text-white font-bold py-3 px-8 rounded-full hover:bg-brand-green-dark transition-transform duration-300 transform hover:scale-105 shadow-lg">
          Discover the Solution
        </a>
      </div>
    </section>
  );
};

export default Hero;