import React from 'react';
import Section from './Section';
import CO2Counter from './CO2Counter';
import AnimateOnScroll from './AnimateOnScroll';

const ProblemSection: React.FC = () => {
  const problems = [
    {
      title: "Fossil Fuel Dependence",
      description: "Traditional synthesis uses natural gas to produce hydrogen, a process that releases significant amounts of CO₂ into the atmosphere."
    },
    {
      title: "Environmental Impact",
      description: "Ammonia production is responsible for approximately 1.8% of total global CO₂ emissions, making it a major contributor to climate change."
    },
    {
      title: "Agricultural Pollution",
      description: "The overuse of ammonia-based fertilizers can lead to water pollution and eutrophication, harming aquatic ecosystems."
    },
    {
      title: "Climate Change",
      description: "As a major source of industrial greenhouse gases, conventional ammonia production accelerates global warming."
    }
  ];

  return (
    <Section
      id="problem"
      title="The Problem with Traditional Ammonia"
      subtitle="The conventional Haber-Bosch process, while revolutionary, comes at a high environmental cost."
      className="bg-white"
    >
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <AnimateOnScroll className="fade-in-up">
          <div className="space-y-6">
            {problems.map((problem, index) => (
              <div key={index}>
                <h3 className="text-xl font-bold text-brand-brown mb-1">{problem.title}</h3>
                <p className="text-gray-600">{problem.description}</p>
              </div>
            ))}
          </div>
        </AnimateOnScroll>
        <AnimateOnScroll className="fade-in-up" style={{ transitionDelay: '200ms' }}>
           <CO2Counter />
          <p className="text-center text-sm text-gray-500 mt-4">
            Annual CO₂ emissions from conventional ammonia production alone.
          </p>
        </AnimateOnScroll>
      </div>
    </Section>
  );
};

export default ProblemSection;